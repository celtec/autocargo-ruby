var html;
html = '<strong>\n  cup of coffeescript\n</strong>';