var countdown, num;
countdown = (function() {
  var _results;
  _results = [];
  for (num = 10; num >= 1; num--) {
    _results.push(num);
  }
  return _results;
})();