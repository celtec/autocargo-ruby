var one, six, three, two;
six = (one = 1) + (two = 2) + (three = 3);