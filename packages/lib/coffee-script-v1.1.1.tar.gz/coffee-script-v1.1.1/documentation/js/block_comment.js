/*
CoffeeScript Compiler v1.1.1
Released under the MIT License
*/