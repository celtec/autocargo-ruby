var footprints, solipsism;
if ((typeof mind !== "undefined" && mind !== null) && !(typeof world !== "undefined" && world !== null)) {
  solipsism = true;
}
if (typeof speed !== "undefined" && speed !== null) {
  speed;
} else {
  speed = 75;
};
footprints = typeof yeti !== "undefined" && yeti !== null ? yeti : "bear";