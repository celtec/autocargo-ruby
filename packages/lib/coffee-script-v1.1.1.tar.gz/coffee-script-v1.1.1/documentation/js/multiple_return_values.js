var city, forecast, temp, weatherReport, _ref;
weatherReport = function(location) {
  return [location, 72, "Mostly Sunny"];
};
_ref = weatherReport("Berkeley, CA"), city = _ref[0], temp = _ref[1], forecast = _ref[2];