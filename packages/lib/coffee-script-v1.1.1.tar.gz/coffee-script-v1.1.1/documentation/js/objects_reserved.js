$('.account').attr({
  "class": 'active'
});
log(object["class"]);